/* #region angular imports */
import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
/* #endregion */

/* #region 3rd party imports */

/* #endregion */

/* #region app imports */

/* #endregion */


@Component({
    selector: 'selector-create-product-category',
    templateUrl: './create-product-category.component.html',
    styleUrls: ['./create-product-category.component.css',
                './create-product-category.component.scss'],

})
export class SnippetComponent {

/* #region declarations */


/* #endregion */

/* #region constructor */


/* #endregion */

/* #region lifecycle events */


/* #endregion */

/* #region events */


/* #endregion */

/* #region methods */


/* #endregion */

}