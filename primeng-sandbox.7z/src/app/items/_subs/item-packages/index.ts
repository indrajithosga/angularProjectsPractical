// export { ItemPackageModule } from './item-p.module';

export { IItemPackage, ItemPackage } from './item-package.model';
export { ItemPackageService } from './item-package.service';