import { Component, AfterViewInit, OnDestroy, Renderer2 } from '@angular/core';

enum MenuOrientation {
    STATIC,
    OVERLAY
}

@Component({
    // selector: 'app-dashboard',
    templateUrl: './default-layout.component.html',
    styleUrls: ['./default-layout.component.scss']
})
export class DefaultLayoutComponent {
   

   //documentClickListener: any () => void;

}
