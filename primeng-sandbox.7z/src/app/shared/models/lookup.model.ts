
export interface ILookupModel {
  displayText?: string;
  value?: string;
  label?: string;
}

export class LookupModel implements ILookupModel {

  constructor() {
    
  }

  displayText?: string;
  value?: string;
  label?: string;
}