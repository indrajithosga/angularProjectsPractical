export { ItemCategoryModule } from './item-category.module';
//export { ItemCategoryRoutingModule } from './item-category-routing.module';

export { ItemCategory } from './item-category.model';
export { ItemCategoryService } from './item-category.service';
export { CreateItemCategoryComponent } from './create-item-category/create-item-category.component';