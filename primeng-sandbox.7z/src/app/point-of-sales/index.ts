export { PointOfSaleModule } from './point-of-sales.module';

export { IInvoiceItem, InvoiceItem } from './invoice-item.model';