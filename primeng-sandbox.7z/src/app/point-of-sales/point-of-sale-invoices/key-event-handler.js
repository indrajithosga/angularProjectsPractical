window.addEventListener("keydown",function (e) {
    if (e.keyCode === 112) { 
        e.preventDefault();
    }
})